/**
 * Gutenberg Blocks
 *
 * All blocks related JavaScript files should be imported here.
 * You can create a new block folder in this dir and include code
 * for that block here as well.
 *
 * All blocks should be included here since this is the file that
 * Webpack is compiling as the input file.
 */

import './style.scss';

import './blocks/container/block.js';
import './blocks/grid/index.js';
import './blocks/responsive-spacer/block.js';
import './blocks/avatar/block.js';
import './blocks/chip/block.js';
import './blocks/card/block.js';
import './blocks/icon/block.js';
import './blocks/semantic-wrapper/block.js';
