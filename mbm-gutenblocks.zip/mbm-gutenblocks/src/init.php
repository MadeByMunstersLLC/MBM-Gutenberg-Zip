<?php
/**
 * Blocks Initializer
 *
 * Enqueue CSS/JS of all the blocks.
 *
 * @since   1.0.0
 * @package CGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue Gutenberg block assets for both frontend + backend.
 *
 * Assets enqueued:
 * 1. blocks.style.build.css - Frontend + Backend.
 * 2. blocks.build.js - Backend.
 * 3. blocks.editor.build.css - Backend.
 *
 * @uses {wp-blocks} for block type registration & related functions.
 * @uses {wp-element} for WP Element abstraction — structure of blocks.
 * @uses {wp-i18n} to internationalize the block's text.
 * @uses {wp-editor} for WP editor styles.
 * @since 1.0.0
 */
function mbm_gutenblocks_cgb_block_assets() { // phpcs:ignore
	// Register block styles for both frontend + backend.
	$block_styles_file_path = 'dist/blocks.css';
	wp_register_style(
		'mbm_gutenblocks-cgb-style-css',
		plugins_url( $block_styles_file_path, dirname( __FILE__ ) ),
		array( 'wp-editor' ),
		// Version: File modification time.
		filemtime( plugin_dir_path( __DIR__ ) . $block_styles_file_path )
	);

	// Register block editor script for backend.
	// This is only necessary because of the way WebPack splits files. If we
	// don't load this editor chunk, then the blocks module won't execute.
	$editor_chunk_file_path = 'dist/editor.chunk.js';
	wp_register_script(
		'mbm_gutenblocks-cgb-block-editor-js',
		plugins_url( $editor_chunk_file_path, dirname( __FILE__ ) ),
		array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor' ),
		filemtime( plugin_dir_path( __DIR__ ) . $editor_chunk_file_path ),
		true // Enqueue the script in the footer.
	);

	$blocks_module_file_path = 'dist/blocks.module.js';
	wp_register_script(
		'mbm_gutenblocks-cgb-block-js', // Handle.
		plugins_url( $blocks_module_file_path, dirname( __FILE__ ) ),
		array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'mbm_gutenblocks-cgb-block-editor-js' ),
		filemtime( plugin_dir_path( __DIR__ ) . $blocks_module_file_path ),
		true // Enqueue the script in the footer.
	);

	$front_module_file_path = 'dist/front.module.js';
	wp_register_script(
		'mbm_gutenblocks-cgb-block-front-js', // Handle.
		plugins_url( $front_module_file_path, dirname( __FILE__ ) ),
		array( 'jquery' ),
		filemtime( plugin_dir_path( __DIR__ ) . $front_module_file_path ),
		true // Enqueue the script in the footer.
	);
	if (!is_admin()) {
		wp_enqueue_script('mbm_gutenblocks-cgb-block-front-js');
	}

	// Register block editor styles for backend.
	$block_editor_styles_file_path = 'dist/editor.chunk.css';
	wp_register_style(
		'mbm_gutenblocks-cgb-block-editor-css', // Handle.
		plugins_url( $block_editor_styles_file_path, dirname( __FILE__ ) ),
		array( 'wp-edit-blocks' ),
		filemtime( plugin_dir_path( __DIR__ ) . $block_editor_styles_file_path )
	);

	// WP Localized globals. Use dynamic PHP stuff in JavaScript via `cgbGlobal` object.
	wp_localize_script(
		'mbm_gutenblocks-cgb-block-js',
		'cgbGlobal', // Array containing dynamic data for a JS Global.
		[
			'pluginDirPath' => plugin_dir_path( __DIR__ ),
			'pluginDirUrl'  => plugin_dir_url( __DIR__ ),
			// Add more data here that you want to access from `cgbGlobal` object.
		]
	);

	wp_localize_script(
		'mbm_gutenblocks-cgb-block-js',
		'mbmConfig',
		get_option('mbm_gutenblocks_options')
	);

	// Font Awesome
	// FIXME: Extract these strings, load from a common static property.
	$mbm_gutenblocks_options = get_option( 'mbm_gutenblocks_options' );
	if (
		isset( $mbm_gutenblocks_options['mbmgb_field_fa_enabled'] )
		&&
		$mbm_gutenblocks_options['mbmgb_field_fa_enabled'] == '1'
		&&
		isset( $mbm_gutenblocks_options['mbmgb_field_fa_url'] )
	) {
		$font_awesome_url = $mbm_gutenblocks_options['mbmgb_field_fa_url'];
		wp_register_script(
			'mbm_gutenblocks-font-awesome', // Handle.
			$font_awesome_url,
			array( 'jquery' ),
			false,
			true // Enqueue the script in the footer.
		);
		wp_enqueue_script('mbm_gutenblocks-font-awesome');
	}

	/**
	 * Register Gutenberg block on server-side.
	 *
	 * Register the block on server-side to ensure that the block
	 * scripts and styles for both frontend and backend are
	 * enqueued when the editor loads.
	 *
	 * @link https://wordpress.org/gutenberg/handbook/blocks/writing-your-first-block-type#enqueuing-block-scripts
	 * @since 1.16.0
	 */
	register_block_type(
		'mbm/mbm-gutenblocks', array(
			// Enqueue block styles on both frontend & backend.
			'style'         => 'mbm_gutenblocks-cgb-style-css',
			// Enqueue block JS in the editor only.
			'editor_script' => [
				'mbm_gutenblocks-cgb-block-editor-js',
				'mbm_gutenblocks-cgb-block-js'
			],
			// Enqueue block editor styles in the editor/admin only.
			'editor_style'  => 'mbm_gutenblocks-cgb-block-editor-css',
		)
	);
}

// Hook: Block assets.
add_action( 'init', 'mbm_gutenblocks_cgb_block_assets' );
