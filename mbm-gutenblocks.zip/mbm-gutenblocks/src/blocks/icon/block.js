import * as classNames from 'classnames';
import { sizeOptions } from '../shared/sizes.js';
const { __ } = wp.i18n;
const {
  registerBlockType,
} = wp.blocks;
const {
	InnerBlocks,
	InspectorControls,
	PanelColorSettings,
	BlockAlignmentToolbar,
	BlockControls,
	withColors,
	getColorClassName,
} = wp.editor;
const {
	PanelBody,
	PanelRow,
	FormToggle,
	SelectControl,
	RangeControl,
	TextControl,
} = wp.components;
const { compose } = wp.compose;
const { Fragment } = wp.element;

const iconContainer = () => (
	<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="icons" class="svg-inline--fa fa-icons fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M116.65 219.35a15.68 15.68 0 0 0 22.65 0l96.75-99.83c28.15-29 26.5-77.1-4.91-103.88C203.75-7.7 163-3.5 137.86 22.44L128 32.58l-9.85-10.14C93.05-3.5 52.25-7.7 24.86 15.64c-31.41 26.78-33 74.85-5 103.88zm143.92 100.49h-48l-7.08-14.24a27.39 27.39 0 0 0-25.66-17.78h-71.71a27.39 27.39 0 0 0-25.66 17.78l-7 14.24h-48A27.45 27.45 0 0 0 0 347.3v137.25A27.44 27.44 0 0 0 27.43 512h233.14A27.45 27.45 0 0 0 288 484.55V347.3a27.45 27.45 0 0 0-27.43-27.46zM144 468a52 52 0 1 1 52-52 52 52 0 0 1-52 52zm355.4-115.9h-60.58l22.36-50.75c2.1-6.65-3.93-13.21-12.18-13.21h-75.59c-6.3 0-11.66 3.9-12.5 9.1l-16.8 106.93c-1 6.3 4.88 11.89 12.5 11.89h62.31l-24.2 83c-1.89 6.65 4.2 12.9 12.23 12.9a13.26 13.26 0 0 0 10.92-5.25l92.4-138.91c4.88-6.91-1.16-15.7-10.87-15.7zM478.08.33L329.51 23.17C314.87 25.42 304 38.92 304 54.83V161.6a83.25 83.25 0 0 0-16-1.7c-35.35 0-64 21.48-64 48s28.65 48 64 48c35.2 0 63.73-21.32 64-47.66V99.66l112-17.22v47.18a83.25 83.25 0 0 0-16-1.7c-35.35 0-64 21.48-64 48s28.65 48 64 48c35.2 0 63.73-21.32 64-47.66V32c0-19.48-16-34.42-33.92-31.67z"></path></svg>
);

const isFaEnabled = () => {
  return mbmConfig['mbmgb_field_fa_enabled'] && mbmConfig['mbmgb_field_fa_enabled'] === '1';
};

const defaultSize = 'sm';
const defaultPadding = 'sm';
const defaultShape = 'square';

const shapeOptions = [
  {
    value: 'square',
    label: 'Square',
  },
  {
    value: 'circle',
    label: 'Circle',
  },
];

const isShapeSquare = (shape) => !shape || shape === 'square';
const isShapeCircle = (shape) => shape === 'circle';
const isStringNonEmpty = (value) => {
  if (!value) return false;

  if (typeof value !== 'string') return false;

  return value.trim().length > 0;
}

const Icon = (props) => {
  const {
    backgroundColor: backgroundColorAttr,
    customBackgroundColor,
    textColor: textColorAttr,
    customTextColor,
    iconPrefix,
    iconSlug,
    shape,
    borderRadius,
    size,
    padding,
  } = props.attributes;
  const {
    backgroundColor: backgroundColorProps,
    textColor: textColorProps,
    isEdit = false,
  } = props;
  const backgroundClass = getColorClassName( 'background-color', backgroundColorAttr );
  const textClass = getColorClassName( 'color', textColorAttr );

  let backgroundColor = customBackgroundColor;
  if (backgroundColorProps && backgroundColorProps.color) {
    backgroundColor = backgroundColorProps.color;
  }

  let textColor = customTextColor;
  if (textColorProps && textColorProps.color) {
    textColor = textColorProps.color;
  }

  const containerClasses = classNames({
    [props.className]: !!props.className,
		'icon': true,
		'has-background': backgroundColor || customBackgroundColor,
		[backgroundClass]: backgroundClass,
		[textClass]: textClass,
    [`border-radius__${borderRadius}`]: isShapeSquare(shape),
    ['icon--circle']: isShapeCircle(shape),
    [`icon--${size}`]: true,
    [`padding__${padding}`]: true,
  });

  const iconClasses = classNames({
    [iconPrefix]: true,
    [`fa-${iconSlug}`]: true,
  });

  if (isEdit) {
    if (!isFaEnabled()) {
      return (<p>Font Awesome is disabled.</p>);
    }

    if (!isStringNonEmpty(iconPrefix)) {
      return (<p>Icon prefix is empty.</p>);
    }

    if (!isStringNonEmpty(iconSlug)) {
      return (<p>Icon slug is empty.</p>);
    }
  }

  return (
    <div
      className={containerClasses}
      style={{
        backgroundColor: backgroundColor,
        color: textColor,
      }}
    >
      <i className={iconClasses} />
    </div>
  );
};

const edit = ( props ) => {
	const {
    iconPrefix,
    iconSlug,
    shape,
    borderRadius,
    size,
    padding,
	} = props.attributes;
  const {
		backgroundColor,
		setBackgroundColor,
		textColor,
		setTextColor,
  } = props;

	return [
		<InspectorControls>
      {isFaEnabled() ? (
        <Fragment>
          <PanelBody title="Settings">
            <PanelRow>
              <TextControl
                label={__('Icon Prefix')}
                value={iconPrefix}
                onChange={(value) => props.setAttributes({iconPrefix: value})}
              />
            </PanelRow>
            <PanelRow>
              <TextControl
                label={__('Icon Slug')}
                value={iconSlug}
                onChange={(value) => props.setAttributes({iconSlug: value})}
              />
            </PanelRow>
    				<PanelRow>
    					<SelectControl
    						label='Shape'
    						value={shape}
    						options={shapeOptions}
    						onChange={(value) => props.setAttributes({shape: value})}
    					/>
    				</PanelRow>
            {isShapeSquare(shape) && (
              <PanelRow>
                <RangeControl
                  label={__('Border Radius')}
                  value={borderRadius}
                  onChange={(value) => props.setAttributes({borderRadius: value})}
          				min={ 0 }
          				max={ 10 }
                />
              </PanelRow>
            )}
    				<PanelRow>
    					<SelectControl
    						label='Size'
    						value={size}
    						options={sizeOptions}
    						onChange={(value) => props.setAttributes({size: value})}
    					/>
    				</PanelRow>
    				<PanelRow>
    					<SelectControl
    						label='Padding'
    						value={padding}
    						options={sizeOptions}
    						onChange={(value) => props.setAttributes({padding: value})}
    					/>
    				</PanelRow>
          </PanelBody>
    			<PanelColorSettings
    				title={__('Color Settings')}
    				initialOpen={false}
    				colorSettings={[
              {
                label: __('Color'),
                value: textColor.color,
                onChange: setTextColor,
              },
    					{
    						label: __('Background Color'),
    						value: backgroundColor.color,
    						onChange: setBackgroundColor,
    					},
    				]}
    			/>
        </Fragment>
      ) : (
        <PanelRow>
          <p>Font Awesome is disabled.</p>
        </PanelRow>
      )}
		</InspectorControls>
		,
		<Icon
      {...props}
      isEdit={true}
    />
	];
};

const SaveComponent = ( props ) => {
	return (
		<Icon
      {...props}
    />
	);
};

const blockName = 'MBM Icon';
const blockSlug = 'mbm/icon';
registerBlockType(blockSlug, {
	title: __( blockName ),
	description: __( "Add a visual design element (Font Awesome Icon) to a group of content." ),
	icon: iconContainer,
	category: 'common',
	keywords: [
		__( blockName ),
		__( 'icon' ),
	],
  edit: compose(
    withColors('backgroundColor', { textColor: 'color' }),
  )(edit),
	save: SaveComponent,
	attributes: {
		backgroundColor: {
			type: 'string',
			default: null,
		},
		customBackgroundColor: {
			type: 'string',
		},
		textColor: {
			type: 'string',
			default: null,
		},
		customTextColor: {
			type: 'string',
		},
    shape: {
      type: 'string',
      default: defaultShape,
    },
    borderRadius: {
      type: 'number',
      default: 0,
    },
    size: {
      type: 'string',
      default: defaultSize,
    },
    padding: {
      type: 'string',
      default: defaultPadding,
    },
    iconSlug: {
      type: 'string',
    },
    iconPrefix: {
      type: 'string',
    },
	},
});
