//  Import CSS.
import './editor.scss';

import * as classNames from 'classnames';
import { responsiveSizeNames } from '../shared/text.js';
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const {
	InspectorControls,
} = wp.editor;
const {
	Panel,
	PanelBody,
	PanelRow,
	FormToggle,
	SelectControl,
	ToggleControl,
	BaseControl,
} = wp.components;
const { Fragment } = wp.element;

const icon = () => (
	<svg aria-hidden="true" focusable="false" data-prefix="fad" data-icon="arrows-v" class="svg-inline--fa fa-arrows-v fa-w-8" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512"><g class="fa-group"><path class="fa-secondary" fill="currentColor" d="M160 106.34v299.32l-32 33.77-32-33.77V106.34l32-33.77z" opacity="0.4"></path><path class="fa-primary" fill="currentColor" d="M18.37 153.41a23.93 23.93 0 0 0 33.92-.94L128 72.57l75.71 79.9a23.93 23.93 0 0 0 33.92.94L249 142.1a24.15 24.15 0 0 0 0-34L150.62 9.4a31.92 31.92 0 0 0-45.24 0L7 108.05a24.15 24.15 0 0 0 0 34.05zm219.26 205.18a23.93 23.93 0 0 0-33.92.94L128 439.43l-75.71-79.9a23.93 23.93 0 0 0-33.92-.94L7 369.9A24.15 24.15 0 0 0 7 404l98.36 98.65a31.92 31.92 0 0 0 45.24 0L249 404a24.15 24.15 0 0 0 0-34.05z"></path></g></svg>
);

const DivWrapper = ( props ) => {
	const {
		responsive,
		allSize,
		smSize,
		mdSize,
		lgSize,
	} = props.attributes;
  const {
    isEdit = false,
  } = props;
	const classes = classNames({
		[`spacer__${allSize}`]: true,
		[`spacer__sm-${smSize}`]: responsive && smSize !== null,
		[`spacer__md-${mdSize}`]: responsive && mdSize !== null,
		[`spacer__lg-${lgSize}`]: responsive && lgSize !== null,
		[props.className]: !!props.className,
	});

	return (
		<div
			className={ classes }
		/>
	);
};

const defaultSpacing = 16;
const spacingOptions = [0, 1, 2, 4, 8, 12, 16, 24, 32, 48, 64, 128]
	.map((intValue) => {
		const valueStr = intValue.toString();
		return {
			value: valueStr,
			label: valueStr,
		};
	});

const SizingControls = ({size}) => {
	return (
		<SelectControl
			label={ __( 'Size' ) }
      options={spacingOptions}
			value={ size.value }
			onChange={ size.onChange }
		/>
	);
}

const EditComponent = ( props ) => {
	const {
		responsive,
		allSize,
		smSize,
		mdSize,
		lgSize,
	} = props.attributes;

	return [
		<InspectorControls>
			{/* Whatever is inside this block will be displayed on the sidebar */}
			<PanelBody
				title="Layout Settings"
			>
				<ToggleControl
					label={ __( 'Responsive' ) }
					help={ responsive ? 'Does this element have the same size no matter the viewport size?' : 'Do you want to set multiple sizes for this element?' }
					checked={ responsive }
					onChange={ (newResponsive) => {
            props.setAttributes({
              responsive: newResponsive,
              allSize,
              smSize,
              mdSize,
              lgSize,
            });
          }}
				/>
				{!responsive && (
					<SizingControls
						size={{
							value: allSize,
              onChange: (value) => props.setAttributes({allSize: parseInt(value, 10)})
						}}
					/>
				)}
				{responsive && (
					<Fragment>
						<BaseControl>
							<p className="label__spacing"><b>{ responsiveSizeNames.all }</b></p>
							<p><i>(Standard mobile phones)</i></p>
							<SizingControls
								size={{
									value: allSize,
									onChange: (value) => props.setAttributes({allSize: parseInt(value, 10)})
								}}
							/>
						</BaseControl>
						<hr/>
						<BaseControl>
							<p className="label__spacing"><b>{ responsiveSizeNames.sm }</b></p>
							<p><i>(Large mobile phones, small tablets)</i></p>
							<SizingControls
								size={{
									value: smSize,
									onChange: (value) => props.setAttributes({smSize: parseInt(value, 10)})
								}}
							/>
						</BaseControl>
						<hr/>
						<BaseControl>
							<p className="label__spacing"><b>{ responsiveSizeNames.md }</b></p>
							<p><i>(Standard tablets, small laptops)</i></p>
							<SizingControls
								size={{
									value: mdSize,
									onChange: (value) => props.setAttributes({mdSize: parseInt(value, 10)})
								}}
							/>
						</BaseControl>
						<hr/>
						<BaseControl>
							<p className="label__spacing"><b>{ responsiveSizeNames.lg }</b></p>
							<p><i>(Large tablets, desktop computers)</i></p>
							<SizingControls
								size={{
									value: lgSize,
									onChange: (value) => props.setAttributes({lgSize: parseInt(value, 10)})
								}}
							/>
						</BaseControl>
					</Fragment>
				)}
			</PanelBody>
		</InspectorControls>
		,
		<DivWrapper
			{...props}
			isEdit={true}
		/>
	];
};

const SaveComponent = ( props ) => {
	return (
		<DivWrapper {...props} />
	);
};

const blockName = 'MBM Responsive Spacer';
const blockSlug = 'mbm/responsive-spacer';
registerBlockType(blockSlug, {
	title: __( blockName ),
	description: __( "You gotta keep 'em separated. Control spacing between elements based on breakpoints." ),
	icon: icon,
	category: 'layout',
	keywords: [
		__( blockName ),
		__( 'spacer' ),
	],
	edit: EditComponent,
	save: SaveComponent,
	attributes: {
		responsive: {
			type: 'boolean',
			default: false,
		},
		allSize: {
			type: 'number',
			default: defaultSpacing,
		},
		smSize: {
			type: 'number',
			default: defaultSpacing,
		},
		mdSize: {
			type: 'number',
			default: defaultSpacing,
		},
		lgSize: {
			type: 'number',
			default: defaultSpacing,
		},
	},
});
