import * as classNames from 'classnames';
import {
  ariaLabelParser,
  ariaLabelAttribute,
  AriaLabelPanel,
} from '../shared/accessibility/AriaLabelPanel';
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const {
	InnerBlocks,
	InspectorControls,
} = wp.editor;
const {
	Panel,
	PanelBody,
	PanelRow,
	FormToggle,
	SelectControl,
	ToggleControl,
	BaseControl,
} = wp.components;
const { Fragment } = wp.element;

const icon = () => (
	<svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="html5" class="svg-inline--fa fa-html5 fa-w-12" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M0 32l34.9 395.8L191.5 480l157.6-52.2L384 32H0zm308.2 127.9H124.4l4.1 49.4h175.6l-13.6 148.4-97.9 27v.3h-1.1l-98.7-27.3-6-75.8h47.7L138 320l53.5 14.5 53.7-14.5 6-62.2H84.3L71.5 112.2h241.1l-4.4 47.7z"></path></svg>
);

const tagTypeOptions = [
	{
		label: 'Article',
		value: 'article',
	},
	{
		label: 'Aside',
		value: 'aside',
	},
	{
		label: 'Figure',
		value: 'figure',
	},
	{
		label: 'Footer',
		value: 'footer',
	},
	{
		label: 'Header',
		value: 'header',
	},
	{
		label: 'Section',
		value: 'section',
	},
];
const defaultTagType = 'section';

const Renderer = ( props ) => {
	const {
		tagType,
	} = props.attributes;

	// Verify tag type selection is in whitelist.
	const tagTypeOption = tagTypeOptions.find(
		(tagTypeOption) => tagTypeOption.value === tagType
	);
	if (!tagTypeOption) {
		return (<p>Error: could not identify semantic tag type.</p>);
	}

	const TagRenderer = tagType;

	return (
		<TagRenderer
			{...props}
      {...ariaLabelParser(props)}
		/>
	);
};

const EditComponent = ( props ) => {
	const {
		tagType,
	} = props.attributes;

	return [
		<InspectorControls>
			<PanelBody
				title="Settings"
			>
				<PanelRow>
					<SelectControl
						label='Tag Type'
						value={tagType}
						options={tagTypeOptions}
						onChange={(value) => props.setAttributes({tagType: value})}
					/>
				</PanelRow>
			</PanelBody>
      <AriaLabelPanel {...props} />
		</InspectorControls>
		,
		<Renderer
			{...props}
			isEdit={true}
		>
			<InnerBlocks />
		</Renderer>
	];
};

const SaveComponent = ( props ) => {
	return (
		<Renderer {...props}>
			<InnerBlocks.Content />
		</Renderer>
	);
};

const blockName = 'MBM Semantic Wrapper';
const blockSlug = 'mbm/semantic-wrapper';
registerBlockType(blockSlug, {
	title: __( blockName ),
	description: __( "Looking to be more semantic? Look no further. Use this block to insert an HTML5 element into your layout." ),
	icon: icon,
	category: 'layout',
	keywords: [
		__( blockName ),
		__( 'semantic' ),
		__( 'wrapper' ),
	],
	edit: EditComponent,
	save: SaveComponent,
	attributes: {
		tagType: {
			type: 'string',
			default: defaultTagType,
		},
    ...ariaLabelAttribute,
	},
});
