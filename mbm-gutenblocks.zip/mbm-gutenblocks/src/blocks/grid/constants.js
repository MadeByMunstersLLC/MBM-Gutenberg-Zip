export const slugs = {
  container: 'mbm/grid-container',
  column: 'mbm/grid-column',
};
