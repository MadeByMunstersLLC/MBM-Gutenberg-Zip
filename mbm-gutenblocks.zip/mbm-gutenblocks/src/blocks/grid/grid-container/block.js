//  Import CSS.
import './editor.scss';

import * as classNames from 'classnames';
import { slugs } from '../constants.js';
import { responsiveSizeNames } from '../../shared/text.js';
import { VisibilityPanel } from '../../shared/visibility';
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const {
	InnerBlocks,
	InspectorControls,
} = wp.editor;
const {
	PanelBody,
	PanelRow,
	FormToggle,
	SelectControl,
	ToggleControl,
} = wp.components;
const { Fragment } = wp.element;

const DivWrapper = ( props ) => {
	const {
		responsive,
		alignAll,
		alignSm,
		alignMd,
		alignLg,
    visibility,
	} = props.attributes;
  const {
    isEdit = false,
  } = props;

	const classes = classNames(
		'row',
		{
			[props.className]: !!props.className,
			[`row__all-${alignAll}`]: alignAll,
			[`row__sm-${alignSm}`]: responsive && alignSm,
			[`row__md-${alignMd}`]: responsive && alignMd,
			[`row__lg-${alignLg}`]: responsive && alignLg,
	    // Augment with visibility classes
	    [visibility]: !isEdit && !!visibility,
		}
	);

	return (
		<div className={ classes }>
			{ props.children }
		</div>
	);
};

const template = [
	[slugs.column, { }],
];

const alignmentOptions = [
	{
		label: 'Align Top',
		value: 'start',
	},
	{
		label: 'Align Center',
		value: 'center',
	},
	{
		label: 'Align Bottom',
		value: 'end',
	},
];

const iconGridContainer = () => (
	<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="columns" class="svg-inline--fa fa-columns fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M464 32H48C21.49 32 0 53.49 0 80v352c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V80c0-26.51-21.49-48-48-48zM224 416H64V160h160v256zm224 0H288V160h160v256z"></path></svg>
);

const edit = ( props ) => {
	const {
		responsive,
		alignAll,
		alignSm,
		alignMd,
		alignLg,
    visibility,
	} = props.attributes;

	return [
		<InspectorControls>
			{/* Whatever is inside this block will be displayed on the sidebar */}
			<PanelBody title={ __( 'Alignment Settings' ) }>
				<ToggleControl
					label={ __( 'Responsive' ) }
					help={ responsive ? 'Control aligment per viewport size.' : 'Set one alignment for all viewport sizes.' }
					checked={ responsive }
					onChange={ (value) => props.setAttributes({responsive: value}) }
				/>
				{!responsive && (
					<SelectControl
						label='Alignment'
						value={alignAll}
						options={alignmentOptions}
						onChange={(value) => props.setAttributes({alignAll: value})}
					/>
				)}
				{responsive && (
					<Fragment>
						<SelectControl
							label={responsiveSizeNames.all}
							value={alignAll}
							options={alignmentOptions}
							onChange={(value) => props.setAttributes({alignAll: value})}
						/>
						<SelectControl
							label={responsiveSizeNames.sm}
							value={alignSm}
							options={alignmentOptions}
							onChange={(value) => props.setAttributes({alignSm: value})}
						/>
						<SelectControl
							label={responsiveSizeNames.md}
							value={alignMd}
							options={alignmentOptions}
							onChange={(value) => props.setAttributes({alignMd: value})}
						/>
						<SelectControl
							label={responsiveSizeNames.lg}
							value={alignLg}
							options={alignmentOptions}
							onChange={(value) => props.setAttributes({alignLg: value})}
						/>
					</Fragment>
				)}
			</PanelBody>
      <VisibilityPanel
        visibility={visibility}
        setAttributes={props.setAttributes}
      />
		</InspectorControls>
		,
		<DivWrapper
			{...props}
			isEdit={true}
		>
			<InnerBlocks
				template={template}
				allowedBlocks={[slugs.column]}
				templateLock={false}
			/>
		</DivWrapper>
	];
};

const save = ( props ) => {
	return (
		<DivWrapper {...props}>
			<InnerBlocks.Content />
		</DivWrapper>
	);
};

const blockName = 'MBM Grid';
registerBlockType(slugs.container, {
	title: __( blockName ),
	description: __( "Row that contains columns" ),
	icon: iconGridContainer,
	category: 'layout',
	keywords: [
		__( blockName ),
		__( 'grid' ),
	],
	edit: edit,
	save: save,
	attributes: {
		responsive: {
			type: 'boolean',
			default: false,
		},
		alignAll: {
			type: 'string',
			default: 'start',
		},
		alignSm: {
			type: 'string',
			default: 'start',
		},
		alignMd: {
			type: 'string',
			default: 'start',
		},
		alignLg: {
			type: 'string',
			default: 'start',
		},
    visibility: {
      type: 'string',
      default: undefined,
    },
	},
	supports: {
    align: false
	},
});
