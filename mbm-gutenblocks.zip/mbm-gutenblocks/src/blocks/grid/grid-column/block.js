//  Import CSS.
import './editor.scss';

import * as classNames from 'classnames';
import { slugs } from '../constants.js';
import { responsiveSizeNames } from '../../shared/text.js';
import { VisibilityPanel } from '../../shared/visibility';
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const {
	InnerBlocks,
	InspectorControls,
} = wp.editor;
const {
	Panel,
	PanelBody,
	PanelRow,
	FormToggle,
	SelectControl,
	RangeControl,
	ToggleControl,
	BaseControl,
} = wp.components;
const { Fragment } = wp.element;

const iconGrid = () => (
	<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="container-storage" class="svg-inline--fa fa-container-storage fa-w-20" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path fill="currentColor" d="M640 80V48c0-8.8-7.2-16-16-16H16C7.2 32 0 39.2 0 48v32c0 8.8 7.2 16 16 16v320c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h608c8.8 0 16-7.2 16-16v-32c0-8.8-7.2-16-16-16V96c8.8 0 16-7.2 16-16zM448 416h-32V96h32v320zM192 96h32v320h-32V96zm144 320h-32V96h32v320zM80 96h32v320H80V96zm480 320h-32V96h32v320z"></path></svg>
);

const DivWrapper = ( props ) => {
	const {
		responsive,
		allSize,
		allOffset,
		smSize,
		smOffset,
		mdSize,
		mdOffset,
		lgSize,
		lgOffset,
    visibility,
	} = props.attributes;
  const {
    isEdit = false,
  } = props;

	// TODO: Too many !isEdit checks here. Rewrite into an if statement.
	const classes = classNames({
		/* NOTE: We need to remove the column size of of the editor element because otherwise we essentially nest a column in a column. */
		[`col__${allSize}`]: !isEdit && true,
		[`offset__${allOffset}`]: !isEdit && allOffset > 0,
		[`col__sm-${smSize}`]: !isEdit && responsive && smSize,
		[`offset__sm-${smOffset}`]: !isEdit && responsive &&  smOffset > 0,
		[`col__md-${mdSize}`]: !isEdit && responsive && mdSize,
		[`offset__md-${mdOffset}`]: !isEdit && responsive &&  mdOffset > 0,
		[`col__lg-${lgSize}`]: !isEdit && responsive && lgSize,
		[`offset__lg-${lgOffset}`]: !isEdit && responsive && lgOffset > 0,
		['editor-col']: isEdit,
		[props.className]: !!props.className,
    // Augment with visibility classes
    [visibility]: !isEdit && !!visibility,
	});

	return (
		<div className={ classes }>
			{ props.children }
		</div>
	);
};

const WidthOffsetControls = ({size, offset}) => {
	return (
		<Fragment>
			<RangeControl
				label={ __( 'Columns' ) }
				value={ size.value }
				onChange={ size.onChange }
				min={ 1 }
				max={ 12 }
			/>
			<RangeControl
				label={ __( 'Offset' ) }
				value={ offset.value }
				onChange={ offset.onChange }
				min={ 0 }
				max={ 11 }
			/>
		</Fragment>
	);
}

const EditComponent = ( props ) => {
	const {
		responsive,
		allSize,
		allOffset,
		smSize,
		smOffset,
		mdSize,
		mdOffset,
		lgSize,
		lgOffset,
    visibility,
	} = props.attributes;

	return [
		<InspectorControls>
			{/* Whatever is inside this block will be displayed on the sidebar */}
			<PanelBody
				title="Layout Settings"
			>
				<ToggleControl
					label={ __( 'Responsive' ) }
					help={ responsive ? 'Does this element have the same width no matter the viewport size?' : 'Do you want to set multiple column widths for this element?' }
					checked={ responsive }
					onChange={ (value) => props.setAttributes({responsive: value}) }
				/>
				{!responsive && (
					<WidthOffsetControls
						size={{
							value: allSize,
							onChange: (value) => props.setAttributes({allSize: value})
						}}
						offset={{
							value: allOffset,
							onChange: (value) => props.setAttributes({allOffset: value})
						}}
					/>
				)}
				{responsive && (
					<Fragment>
						<BaseControl>
							<p className="label__spacing"><b>{ responsiveSizeNames.all }</b></p>
							<p><i>(Standard mobile phones)</i></p>
							<WidthOffsetControls
								size={{
									value: allSize,
									onChange: (value) => props.setAttributes({allSize: value})
								}}
								offset={{
									value: allOffset,
									onChange: (value) => props.setAttributes({allOffset: value})
								}}
							/>
						</BaseControl>
						<hr/>
						<BaseControl>
							<p className="label__spacing"><b>{ responsiveSizeNames.sm }</b></p>
							<p><i>(Large mobile phones, small tablets)</i></p>
							<WidthOffsetControls
								size={{
									value: smSize,
									onChange: (value) => props.setAttributes({smSize: value})
								}}
								offset={{
									value: smOffset,
									onChange: (value) => props.setAttributes({smOffset: value})
								}}
							/>
						</BaseControl>
						<hr/>
						<BaseControl>
							<p className="label__spacing"><b>{ responsiveSizeNames.md }</b></p>
							<p><i>(Standard tablets, small laptops)</i></p>
							<WidthOffsetControls
								size={{
									value: mdSize,
									onChange: (value) => props.setAttributes({mdSize: value})
								}}
								offset={{
									value: mdOffset,
									onChange: (value) => props.setAttributes({mdOffset: value})
								}}
							/>
						</BaseControl>
						<hr/>
						<BaseControl>
							<p className="label__spacing"><b>{ responsiveSizeNames.lg }</b></p>
							<p><i>(Large tablets, desktop computers)</i></p>
							<WidthOffsetControls
								size={{
									value: lgSize,
									onChange: (value) => props.setAttributes({lgSize: value})
								}}
								offset={{
									value: lgOffset,
									onChange: (value) => props.setAttributes({lgOffset: value})
								}}
							/>
						</BaseControl>
					</Fragment>
				)}
			</PanelBody>
      <VisibilityPanel
        visibility={visibility}
        setAttributes={props.setAttributes}
      />
		</InspectorControls>
		,
		<DivWrapper
			{...props}
			isEdit={true}
		>
			<InnerBlocks
				templateLock={false}
			/>
		</DivWrapper>
	];
};

const SaveComponent = ( props ) => {
	return (
		<DivWrapper {...props}>
			<InnerBlocks.Content />
		</DivWrapper>
	);
};

const defaultSize = 6;
const defaultOffset = 0;
const blockName = 'MBM Grid Column';
registerBlockType(slugs.column, {
	title: __( blockName ),
	description: __( "Holds content, but in a pretty grid format." ),
	icon: iconGrid,
	category: 'layout',
	keywords: [
		__( blockName ),
		__( 'column' ),
	],
	edit: EditComponent,
	save: SaveComponent,
	parent: [slugs.container],
	attributes: {
		responsive: {
			type: 'boolean',
			default: false,
		},
		allSize: {
			type: 'number',
			default: defaultSize,
		},
		allOffset: {
			type: 'number',
			default: defaultOffset,
		},
		smSize: {
			type: 'number',
			default: defaultSize,
		},
		smOffset: {
			type: 'number',
			default: defaultOffset,
		},
		mdSize: {
			type: 'number',
			default: defaultSize,
		},
		mdOffset: {
			type: 'number',
			default: defaultOffset,
		},
		lgSize: {
			type: 'number',
			default: defaultSize,
		},
		lgOffset: {
			type: 'number',
			default: defaultOffset,
		},
    visibility: {
      type: 'string',
      default: undefined,
    },
	},
});

const { createHigherOrderComponent } = wp.compose;
const withGridClasses = createHigherOrderComponent(
	( BlockListBlock ) => {
    return ( props ) => {
			if (props.name !== slugs.column) {
				return <BlockListBlock { ...props } />;
			}

			const {
				responsive,
				allSize,
				allOffset,
				smSize,
				smOffset,
				mdSize,
				mdOffset,
				lgSize,
				lgOffset,
			} = props.attributes;

			// console.log(`attributes:`, props.attributes)

			const classes = classNames({
				['editor']: true,
				[`col__${allSize}`]: true,
				[`offset__${allOffset}`]: allOffset > 0,
				[`col__sm-${smSize}`]: responsive && smSize,
				[`offset__sm-${smOffset}`]: responsive &&  smOffset > 0,
				[`col__md-${mdSize}`]: responsive && mdSize,
				[`offset__md-${mdOffset}`]: responsive &&  mdOffset > 0,
				[`col__lg-${lgSize}`]: responsive && lgSize,
				[`offset__lg-${lgOffset}`]: responsive && lgOffset > 0,
			});

      return (
				<BlockListBlock
					{ ...props }
					className={ classes }
				/>
			);
    };
	},
	'withGridClasses'
);

wp.hooks.addFilter(
	'editor.BlockListBlock',
	slugs.column,
	withGridClasses
);
