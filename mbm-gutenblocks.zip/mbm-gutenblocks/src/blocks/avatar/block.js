import * as classNames from 'classnames';
import { sizeOptions } from '../shared/sizes.js';
import Avatar from '../shared/components/Avatar';
import AvatarSettingsPanel from './AvatarSettingsPanel';
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const {
	InspectorControls,
	MediaPlaceholder,
} = wp.editor;
const {
	Panel,
	PanelBody,
	PanelRow,
	FormToggle,
	SelectControl,
	ToggleControl,
	TextControl,
	Button,
	SVG,
	Path,
} = wp.components;
const { Fragment } = wp.element;

const icon = () => (
	<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512"><path fill="currentColor" d="M248 8C111 8 0 119 0 256s111 248 248 248 248-111 248-248S385 8 248 8zm0 96c48.6 0 88 39.4 88 88s-39.4 88-88 88-88-39.4-88-88 39.4-88 88-88zm0 344c-58.7 0-111.3-26.6-146.5-68.2 18.8-35.4 55.6-59.8 98.5-59.8 2.4 0 4.8.4 7.1 1.1 13 4.2 26.6 6.9 40.9 6.9 14.3 0 28-2.7 40.9-6.9 2.3-.7 4.7-1.1 7.1-1.1 42.9 0 79.7 24.4 98.5 59.8C359.3 421.4 306.7 448 248 448z"></path></svg>
);

const defaultSize = 'md';

const EditComponent = ( props ) => {
	const {
		name,
		size,
		imageId,
		imageAlt,
		imageUrl,
	} = props.attributes;

	return [
		<InspectorControls>
			{/* Whatever is inside this block will be displayed on the sidebar */}
			<AvatarSettingsPanel
				title="Settings"
				name={name}
				size={size}
				imageUrl={imageUrl}
				onChangeName={(value) => props.setAttributes({name: value})}
				onChangeSize={(value) => props.setAttributes({size: value})}
				onChangeMedia={(media) => {
					if (media) {
						props.setAttributes({
							imageAlt: media.alt,
							imageId: media.id,
							imageUrl: media.url,
						});
					} else {
						props.setAttributes({
							imageAlt: null,
							imageId: null,
							imageUrl: null,
						});
					}
				}}
			/>
		</InspectorControls>
		,
		<Avatar
			title={name}
			size={size}
			imageUrl={imageUrl}
		/>
	];
};

const SaveComponent = ( props ) => {
	const {
		name,
		size,
		imageUrl,
	} = props.attributes;

	return (
		<Avatar
			title={name}
			size={size}
			imageUrl={imageUrl}
		/>
	);
};

const blockName = 'MBM Avatar';
const blockSlug = 'mbm/avatar';
registerBlockType(blockSlug, {
	title: __( blockName ),
	description: __( "Better than the movie. But maybe that's not saying much." ),
	icon: icon,
	category: 'common',
	keywords: [
		__( blockName ),
		__( 'avatar' ),
	],
	edit: EditComponent,
	save: SaveComponent,
	attributes: {
		name: {
			type: 'string',
		},
		size: {
			type: 'string',
			default: defaultSize,
		},
		imageId: {
			type: 'number',
		},
		imageAlt: {
			type: 'string',
		},
		imageUrl: {
			type: 'string',
		},
	},
});
