import { sizeOptions } from '../shared/sizes.js';
const { __ } = wp.i18n;
const {
	MediaPlaceholder,
} = wp.editor;
const {
	Panel,
	PanelBody,
	PanelRow,
	FormToggle,
	SelectControl,
	ToggleControl,
	TextControl,
	Button,
	SVG,
	Path,
} = wp.components;
const { Fragment } = wp.element;

const AvatarSettingsPanel = ({
	title = 'Settings',
	name,
	size,
	imageUrl,
	onChangeName,
	onChangeSize,
	onChangeMedia,
}) => {
	return (
		<PanelBody
			title={title}
		>
			<PanelRow>
				<TextControl
					label={ __( 'Title' ) }
					value={ name }
					onChange={onChangeName}
				/>
			</PanelRow>
			<PanelRow>
				<SelectControl
					label='Size'
					value={size}
					options={sizeOptions}
					onChange={onChangeSize}
				/>
			</PanelRow>
			{!!imageUrl ? (
				<Fragment>
					<PanelRow>
						<img
							alt={ name }
							title={ name }
							src={ imageUrl }
						/>
					</PanelRow>
					<PanelRow>
						<Button
							onClick={() => onChangeMedia(null)}
						>
							{ __( 'Remove Image' ) }
						</Button>
					</PanelRow>
				</Fragment>
			) : (
				<PanelRow>
					<MediaPlaceholder
						accept="image/*"
						allowedTypes={['image']}
						onSelect={(media) => onChangeMedia(media)}
					/>
				</PanelRow>
			)}
		</PanelBody>
	)
};

export default AvatarSettingsPanel;
