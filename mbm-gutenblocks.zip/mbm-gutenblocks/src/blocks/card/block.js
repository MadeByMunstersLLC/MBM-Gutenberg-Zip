import {
  Card,
  defaultPadding,
} from '../shared/components/Card';
import { sizeOptions } from '../shared/sizes.js';
const { __ } = wp.i18n;
const {
  registerBlockType,
} = wp.blocks;
const {
	InnerBlocks,
	InspectorControls,
	PanelColorSettings,
	BlockAlignmentToolbar,
	BlockControls,
	withColors,
	getColorClassName,
} = wp.editor;
const {
	PanelBody,
	PanelRow,
	FormToggle,
	SelectControl,
	RangeControl,
	ColorPalette,
} = wp.components;
const { compose } = wp.compose;

const icon = () => (
	<svg aria-hidden="true" focusable="false" data-prefix="fad" data-icon="square" class="svg-inline--fa fa-square fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><g class="fa-group"><path class="fa-secondary" fill="currentColor" d="M400 32H48A48 48 0 0 0 0 80v352a48 48 0 0 0 48 48h352a48 48 0 0 0 48-48V80a48 48 0 0 0-48-48zm-16 368a16 16 0 0 1-16 16H80a16 16 0 0 1-16-16V112a16 16 0 0 1 16-16h288a16 16 0 0 1 16 16z" opacity="0.4"></path><path class="fa-primary" fill="currentColor" d="M64 400V112a16 16 0 0 1 16-16h288a16 16 0 0 1 16 16v288a16 16 0 0 1-16 16H80a16 16 0 0 1-16-16z"></path></g></svg>
);


const DivWrapper = (props) => {
  const {
    backgroundColor: backgroundColorAttr,
    customBackgroundColor,
    borderColor: borderColorAttr,
    customBorderColor,
    borderRadius,
    padding,
  } = props.attributes;
  const {
    backgroundColor: backgroundColorProps,
    borderColor: borderColorProps,
    className,
  } = props;
  const backgroundClass = getColorClassName( 'background-color', backgroundColorAttr );
  const borderClass = getColorClassName( 'border-color', borderColorAttr );

  let backgroundColor = customBackgroundColor;
  if (backgroundColorProps && backgroundColorProps.color) {
    backgroundColor = backgroundColorProps.color;
  }

  let borderColor = customBorderColor;
  if (borderColorProps && borderColorProps.color) {
    borderColor = borderColorProps.color;
  }

  return (
    <Card
      {...{
        className,
        backgroundClass,
        backgroundColor,
        borderClass,
        borderColor,
        borderRadius,
        padding,
      }}
    >
      { props.children }
    </Card>
  );
};

const edit = ( props ) => {
	const {
    borderRadius,
    padding,
	} = props.attributes;
  const {
		backgroundColor,
		setBackgroundColor,
		borderColor,
		setBorderColor,
  } = props;

	return [
		<InspectorControls>
			<PanelColorSettings
				title={ __( 'Color Settings' ) }
				initialOpen={ false }
				colorSettings={ [
					{
						label: __( 'Background Color' ),
						value: backgroundColor.color,
						onChange: setBackgroundColor,
					},
					{
						label: __( 'Border Color' ),
						value: borderColor.color,
						onChange: setBorderColor,
					},
				] }
			>
			</PanelColorSettings>
			<PanelBody title="Layout Settings">
				<p>Border Radius</p>
        <PanelRow>
          <RangeControl
            value={borderRadius}
            onChange={(value) => props.setAttributes({borderRadius: value})}
    				min={ 0 }
    				max={ 10 }
          />
        </PanelRow>
				<PanelRow>
					<SelectControl
						label='Padding'
						value={padding}
						options={sizeOptions}
						onChange={(value) => props.setAttributes({padding: value})}
					/>
				</PanelRow>
      </PanelBody>
		</InspectorControls>
		,
		<DivWrapper
      {...props}
      isEdit={true}
    >
			<InnerBlocks />
    </DivWrapper>
	];
};

const SaveComponent = ( props ) => {
	return (
		<DivWrapper {...props}>
				<InnerBlocks.Content />
		</DivWrapper>
	);
};

const blockName = 'MBM Card';
const blockSlug = 'mbm/card';
registerBlockType(blockSlug, {
	title: __( blockName ),
	description: __( "Add a container to your grid element content to make it stand out amongst the rest." ),
	icon: icon,
	category: 'layout',
	keywords: [
		__( blockName ),
		__( 'card' ),
	],
  edit: compose(
    withColors('backgroundColor', 'borderColor'),
  )(edit),
	save: SaveComponent,
	attributes: {
		backgroundColor: {
			type: 'string',
			default: null,
		},
		customBackgroundColor: {
			type: 'string',
		},
		borderColor: {
			type: 'string',
			default: null,
		},
		customBorderColor: {
			type: 'string',
		},
    borderRadius: {
      type: 'number',
      default: 0,
    },
    padding: {
      type: 'string',
      default: defaultPadding,
    },
	},
});
