//  Import CSS.
import './editor.scss';

import * as classNames from 'classnames';
import { VisibilityPanel } from '../shared/visibility';
import {
  ariaLabelParser,
  ariaLabelAttribute,
  AriaLabelPanel,
} from '../shared/accessibility/AriaLabelPanel';
const { __ } = wp.i18n;
const {
  registerBlockType,
} = wp.blocks;
const {
	InnerBlocks,
	InspectorControls,
	PanelColorSettings,
	BlockAlignmentToolbar,
	BlockControls,
	withColors,
	getColorClassName,
} = wp.editor;
const {
	PanelBody,
	PanelRow,
	FormToggle,
	SelectControl,
	ColorPalette,
} = wp.components;
const { compose } = wp.compose;

const icon = () => (
	<svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="stop" class="svg-inline--fa fa-stop fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M400 32H48C21.5 32 0 53.5 0 80v352c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V80c0-26.5-21.5-48-48-48zm-6 400H54c-3.3 0-6-2.7-6-6V86c0-3.3 2.7-6 6-6h340c3.3 0 6 2.7 6 6v340c0 3.3-2.7 6-6 6z"></path></svg>
);

const DivWrapper = (props) => {
  const {
    backgroundColor: backgroundColorAttr,
    customBackgroundColor,
    topSpacing,
    bottomSpacing,
    visibility,
  } = props.attributes;
  const {
    backgroundColor: backgroundColorProps,
    isEdit = false,
  } = props;
  const backgroundClass = getColorClassName( 'background-color', backgroundColorAttr );

  let backgroundColor = customBackgroundColor;
  if (backgroundColorProps && backgroundColorProps.color) {
    backgroundColor = backgroundColorProps.color;
  }

  const classes = classNames({
    [props.className]: !!props.className,
    // Augment with visibility classes
    [visibility]: !isEdit && !!visibility,
		'has-background': backgroundColor || customBackgroundColor,
		[backgroundClass]: backgroundClass,
  });

  return (
    <section
      className={ classes }
      style={{
        paddingTop: topSpacing ? `${topSpacing}px` : `${defaultSpacing}px`,
        paddingBottom: bottomSpacing ? `${bottomSpacing}px` : `${defaultSpacing}px`,
        backgroundColor: backgroundColor,
      }}
      {...ariaLabelParser(props)}
    >
      <div className='container'>
        { props.children }
      </div>
    </section>
  );
};

const defaultSpacing = 16;
const spacingOptions = [0, 1, 2, 4, 8, 16, 32, 64, 128]
	.map((intValue) => {
		const valueStr = intValue.toString();
		return {
			value: valueStr,
			label: valueStr,
		};
	});

const edit = ( props ) => {
	const {
		topSpacing,
		bottomSpacing,
    visibility,
	} = props.attributes;
  const {
		backgroundColor,
		setBackgroundColor,
  } = props;

	return [
		<InspectorControls>
			{/* Whatever is inside this block will be displayed on the sidebar */}
			<PanelColorSettings
				title={ __( 'Color Settings' ) }
				initialOpen={ false }
				colorSettings={ [
					{
						label: __( 'Background Color' ),
						value: backgroundColor.color,
						onChange: setBackgroundColor,
					},
				] }
			>
			</PanelColorSettings>
			<PanelBody title={ __( 'Spacing Settings' ) } >
				<PanelRow>
					<SelectControl
						label='Top Spacing'
						value={topSpacing}
						options={spacingOptions}
						onChange={(value) => props.setAttributes({topSpacing: value})}
					/>
				</PanelRow>
				<PanelRow>
					<SelectControl
						label='Bottom Spacing'
						value={bottomSpacing}
						options={spacingOptions}
						onChange={(value) => props.setAttributes({bottomSpacing: value})}
					/>
				</PanelRow>
			</PanelBody>
      <VisibilityPanel
        visibility={visibility}
        setAttributes={props.setAttributes}
      />
      <AriaLabelPanel {...props} />
		</InspectorControls>
		,
		<DivWrapper
      {...props}
      isEdit={true}
    >
			<InnerBlocks />
    </DivWrapper>
	];
};

const save = ( props ) => {
	return (
		<DivWrapper {...props}>
			<InnerBlocks.Content />
		</DivWrapper>
	);
};

const blockName = 'MBM Container';
registerBlockType( 'mbm/container', {
	title: __( blockName ),
	description: __( "Add a container to wrap your content. Apply a background color or image." ),
	icon: icon,
	category: 'layout',
	keywords: [
		__( blockName ),
		__( 'container' ),
	],
	// edit: edit,
  edit: compose(
    withColors('backgroundColor'),
  )(edit),
	save: save,
	attributes: {
		align: {
			type: 'string',
			default: 'wide',
		},
		backgroundColor: {
			type: 'string',
			default: null,
		},
		customBackgroundColor: {
			type: 'string',
		},
		topSpacing: {
			type: 'string',
			default: defaultSpacing.toString(),
		},
		bottomSpacing: {
			type: 'string',
			default: defaultSpacing.toString(),
		},
    visibility: {
      type: 'string',
      default: undefined,
    },
    ...ariaLabelAttribute,
	},
	supports: {
		align: ['wide', 'full'],
	},
} );
