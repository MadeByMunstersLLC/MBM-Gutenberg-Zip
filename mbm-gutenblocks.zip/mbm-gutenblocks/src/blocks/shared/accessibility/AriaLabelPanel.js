const { __ } = wp.i18n;
const {
	PanelBody,
	PanelRow,
  TextControl,
} = wp.components;

export const ariaLabelParser = (props) => {
  if (props.attributes && props.attributes.ariaLabel) {
    return {'aria-label': props.attributes.ariaLabel};
  }

  return {};
};

export const ariaLabelAttribute = {
  ariaLabel: {
    type: 'string',
    default: undefined,
  }
};

export const AriaLabelPanel = ({
  attributes,
  setAttributes,
}) => {
  return (
    <PanelBody title={ __( 'Accessibility' ) } >
      <PanelRow>
        <TextControl
          label={ __( 'ARIA Label' ) }
          value={ attributes.ariaLabel }
          onChange={(value) => setAttributes({ariaLabel: value})}
        />
      </PanelRow>
    </PanelBody>
  )
};
