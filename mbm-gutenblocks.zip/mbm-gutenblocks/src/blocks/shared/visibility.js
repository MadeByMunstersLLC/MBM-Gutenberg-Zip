const {
	PanelBody,
	SelectControl,
} = wp.components;
const { __ } = wp.i18n;

const VISIBILITY_OPTIONS = [
  {
    label: 'All Viewports',
    value: '',
  },
  {
    label: 'Small Viewports & Up',
    value: 'hidden--sm-down',
  },
  {
    label: 'Medium Viewports & Up',
    value: 'hidden--md-down',
  },
  {
    label: 'Large Viewports & Up',
    value: 'hidden--lg-down',
  },
  {
    label: 'Medium Viewports & Down',
    value: 'hidden--md-up',
  },
  {
    label: 'Small Viewports & Down',
    value: 'hidden--sm-up',
  },
];

export const VisibilityPanel = ({
  visibility,
  setAttributes,
}) => {
  return (
    <PanelBody
			title={ __( 'Visibility Settings' ) }
			initialOpen={false}
		>
      <SelectControl
        label='Visibility'
        value={visibility}
        options={VISIBILITY_OPTIONS}
        onChange={(value) => {
          const newValue = value && value.trim().length > 0
            ? value
            : null;

          setAttributes({visibility: newValue});
        }}
      />
			<p><i>Determine when this block should be shown based on the viewport size. (Note: The visibility state is reflected on the front-end only.)</i></p>
    </PanelBody>
  );
}
