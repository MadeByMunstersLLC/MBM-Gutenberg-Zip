// import * as classNames from 'classnames';
import classNames from 'classnames';

export const defaultPadding = 'md';

export const Card = ({
  backgroundClass,
  backgroundColor,
  borderClass,
  borderColor,
  shadowClass,
  shadowColor,
  className,
  borderRadius = 0,
  padding = defaultPadding,
  children,
}) => {
  const classes = classNames({
    [className]: !!className,
    'has-background': backgroundColor || backgroundClass,
    [backgroundClass]: backgroundClass,
    'has-border': borderColor || backgroundClass,
    [borderClass]: borderClass,
    'has-shadow': shadowColor || shadowClass,
    [shadowClass]: shadowClass,
    [`border-radius__${borderRadius}`]: true,
    [`padding__${padding}`]: true,
  });

  const styles = {
    backgroundColor: backgroundColor,
    borderColor: borderColor,
    boxShadow: shadowColor && `0px 0px 10px ${shadowColor}`,
  };

  return (
    <div
      className={ classes }
      style={styles}
    >
      { children }
    </div>
  );
};
