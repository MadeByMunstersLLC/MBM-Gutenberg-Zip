import * as classNames from 'classnames';

function abbreviateText(name) {
  let result = '??';

  if (name == null) { name = '??' }

  const nameSections = name.trim().split(' ');

  if (nameSections.length > 1) {
    result = nameSections[0].charAt(0) + nameSections[1].charAt(0);
  } else {
    result = name.substring(0, 2);
  }

  result = result.toUpperCase();

  return result;
}

const Avatar = ({
  title,
  size,
  imageUrl,
  className,
}) => {
	const classes = classNames({
		[className]: !!className,
    'avatar': true,
    // 'margin--auto': true,
    [`avatar--${size}`]: true,
	});

	const abbreviatedText = abbreviateText(title);

	return (
		<div className={classes}>
      {!!imageUrl ? (
        <img
          src={imageUrl}
          className="img"
          alt={title}
        />
      ) : (
        <p className="text">{abbreviatedText}</p>
      )}
    </div>
	);
};

export default Avatar;
