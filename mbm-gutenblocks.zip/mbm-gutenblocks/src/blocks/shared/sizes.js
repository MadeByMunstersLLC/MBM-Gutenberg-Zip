export const sizeOptions = [
	{
		value: 'xs',
		label: 'Extra Small',
	},
	{
		value: 'sm',
		label: 'Small',
	},
	{
		value: 'md',
		label: 'Medium',
	},
	{
		value: 'lg',
		label: 'Large',
	},
	{
		value: 'xlg',
		label: 'Extra Large',
	},
];
