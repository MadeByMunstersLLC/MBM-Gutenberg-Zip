export const responsiveSizeNames = {
  all: 'Extra Small Viewports',
  sm: 'Small Viewports',
  md: 'Medium Viewports',
  lg: 'Large Viewports',
};
