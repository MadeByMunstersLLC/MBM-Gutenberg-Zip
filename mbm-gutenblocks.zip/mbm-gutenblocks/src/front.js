jQuery(() => {
  console.log(`plugin front loaded!`);
})
