const path = require('path');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');

const config = {
  watch: false,
  entry: {
    blocks: './src/blocks.js',
    front: './src/front.js',
    // style: './src/style.scss',
  },
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: '[name].module.js',
    chunkFilename: '[name].chunk.js',
  },
  optimization: {
    splitChunks: {
      cacheGroups: {
        default: false,
        vendors: false,
        // // Merge all the JS into one file
        // scripts: {
        //   name: 'script',
        //   test: /\.js$/,
        //   chunks: 'all',
        //   minChunks: 1,
        //   reuseExistingChunk: true,
        //   enforce: true,
        // },
        editor: {
          name: 'editor',
          test: /editor.scss$/,
          // chunks: 'all',
          chunks: 'initial',
          enforce: true,
        },
      },
    },
  },
  plugins: [
    new MiniCssExtractPlugin({
      // Options similar to the same options in webpackOptions.output
      // all options are optional
      // filename: '[name].css',
      // filename: 'style.css',
      filename: '[name].css',
      chunkFilename: '[name].chunk.css',
      ignoreOrder: false, // Enable to remove warnings about conflicting order
    })
  ],
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader"
        }
      },
      {
        // test: /style \.scss$/,
        test: /\.scss$/,
        exclude: /node_modules/,
        use: [
          {
            loader: MiniCssExtractPlugin.loader,
          },
          'css-loader',
          // Compile Sass to CSS
          'sass-loader',
        ],
      },
    ]
  }
};

module.exports = (env, argv) => {
  if (argv.mode === 'development') {
    config.watch = true;
  }

  return config;
}
