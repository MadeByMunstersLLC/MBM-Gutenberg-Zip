<?php
/**
 * Plugin Name: 			MBM Gutenblocks
 * Plugin URI: 				https://madebymunsters.com/wordpress
 * Description: 			A collection of Gutenberg layout blocks written by Made By Munsters to make custom theme development a breeze.
 * Version: 					1.1.6
 * Requires at least: 5.2
 * Author:            Made by Munsters
 * Author URI:        https://madebymunsters.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 *
 * @package mbm_gutenblocks
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Block Initializer.
 */
require_once plugin_dir_path( __FILE__ ) . 'src/init.php';


/**
* Settings page.
*/
$settings_slug = 'wporg';
$options_slug = 'mbm_gutenblocks_options';

/**
 * custom option and settings
 */
function wporg_settings_init() {
	// register a new setting for "wporg" page
	global $settings_slug;
	global $options_slug;

	register_setting( $settings_slug, $options_slug );

	// register a new section in the "wporg" page
	$section_slug = 'mbmgb_section_font_awesome';
	add_settings_section(
		$section_slug,
		'Font Awesome',
		'mbmgb_section_font_awesome_cb',
		$settings_slug
	);

	// register a new field in the "wporg_section_developers" section, inside the "wporg" page
	$enabled_field_key = 'mbmgb_field_fa_enabled';
	add_settings_field(
		$enabled_field_key, // as of WP 4.6 this value is used only internally
		__( 'Enabled', $settings_slug ),
		$enabled_field_key . '_cb',
		$settings_slug,
		$section_slug,
		[
			'label_for' => $enabled_field_key,
			'class' => 'wporg_row',
		]
	);

	$field_key = 'mbmgb_field_fa_url';
	add_settings_field(
		'wporg_field_text', // as of WP 4.6 this value is used only internally
		__( 'URL', $settings_slug ),
		$field_key . '_cb',
		$settings_slug,
		$section_slug,
		[
			'label_for' => $field_key,
			'class' => 'wporg_row',
			'enabled_field_key' => $enabled_field_key,
		]
	);
}

// section callbacks can accept an $args parameter, which is an array.
// $args have the following keys defined: title, id, callback.
// the values are defined at the add_settings_section() function.
function mbmgb_section_font_awesome_cb( $args ) {
	global $options_slug;
	$options = get_option( $options_slug );
	?>
		<!-- <p>Current option: <pre><?php var_dump($options) ?></pre></p> -->
	<?php
}

// field callbacks can accept an $args parameter, which is an array.
// $args is defined at the add_settings_field() function.
// wordpress has magic interaction with the following keys: label_for, class.
// the "label_for" key value is used for the "for" attribute of the <label>.
// the "class" key value is used for the "class" attribute of the <tr> containing the field.
// you can add custom key value pairs to be used inside your callbacks.
function mbmgb_field_fa_enabled_cb( $args ) {
	global $options_slug;

	// get the value of the setting we've registered with register_setting()
	$options = get_option( $options_slug );
	$option_key = $args['label_for'];

	// output the field
	?>
		<input
			id="<?= esc_attr( $args['label_for'] ); ?>"
			name="<?= $options_slug ?>[<?= esc_attr( $option_key ) ?>]"
			type="checkbox"
			value="1"
			<?php checked( '1', $options[ $option_key ] ); ?>
		/>
	<?php
}

function mbmgb_field_fa_url_cb( $args ) {
	global $options_slug;

	// get the value of the setting we've registered with register_setting()
	$options = get_option( $options_slug );
	$option_key = $args['label_for'];

	if (
		!isset( $options[ $args[ 'enabled_field_key' ] ] )
		||
		$options[ $args[ 'enabled_field_key' ] ] != '1'
	) {
		?>
			<p class="description">
				Ignored while Font Awesome is disabled.
			</p>
		<?php
		return;
	}

	// output the field
	?>
	<div class="acf-label">
		<label>Add Font Awesome JS URL</label>
		<p class="description">This file can be found on Font Awesome's site or from your selected CDN.</p>
		<input
			type="text"
			style="width: 100%; margin-top: 16px"
			name="<?= $options_slug ?>[<?= esc_attr( $option_key ) ?>]"
			value="<?= $options[ $option_key ] ?>"
		>
	</div>
	<?php
}

/**
 * top level menu
 */
function mbm_gutenblocks_options_page() {
	global $settings_slug;

	// add top level menu page
	$page_title = 'Made by Munsters - Custom Gutenblocks';
	$menu_title = 'MBM GB';
	add_menu_page(
		$page_title,
		$menu_title,
		'manage_options',
		$settings_slug,
		'mbm_gutenblocks_options_page_html',
		'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNzIiIGhlaWdodD0iNzIiIHZpZXdCb3g9IjAgMCA3MiA3MiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik04IDBDMy41ODE3MiAwIDAgMy41ODE3MiAwIDhWNjRDMCA2OC40MTgzIDMuNTgxNzIgNzIgOCA3Mkg2NEM2OC40MTgzIDcyIDcyIDY4LjQxODMgNzIgNjRWOEM3MiAzLjU4MTcyIDY4LjQxODMgMCA2NCAwSDhaTTQyLjEyMjcgMjkuOTUzNFYyOS43MDM1QzQyLjEyMjcgMjguNTg4NSA0MS42MjI5IDI4LjA1MDMgNDAuNDY5NSAyOC4wNTAzSDM4Ljc1ODZWMzUuMjIwN0g0MC41MjcyQzQxLjY2MTQgMzUuMjIwNyA0Mi4yMzgxIDM0LjYyNDggNDIuMjM4MSAzMy41MDk4VjMyLjkzMzFDNDIuMjM4MSAzMi4xODM0IDQxLjk4ODIgMzEuNjI1OSA0MS4zOTIyIDMxLjM5NTJDNDEuODkyMSAzMS4xNjQ1IDQyLjEyMjcgMzAuNjgzOSA0Mi4xMjI3IDI5Ljk1MzRaTTM5Ljg3MzYgMzAuOTkxNVYyOS4xMDc2SDQwLjQxMThDNDAuODE1NSAyOS4xMDc2IDQwLjk4ODUgMjkuMzE5IDQwLjk4ODUgMjkuODM4MVYzMC4yNDE4QzQwLjk4ODUgMzAuNzk5MyA0MC43Mzg2IDMwLjk5MTUgNDAuMzE1NyAzMC45OTE1SDM5Ljg3MzZaTTM5Ljg3MzYgMzQuMjIxMVYzMi4wMTA0SDQwLjM3MzRDNDAuODkyNCAzMi4wMTA0IDQxLjEwMzkgMzIuMjAyNiA0MS4xMDM5IDMyLjg3NTRWMzMuNTA5OEM0MS4xMDM5IDM0LjA0ODEgNDAuOTExNiAzNC4yMjExIDQwLjUyNzIgMzQuMjIxMUgzOS44NzM2Wk00Mi4zMzQyIDI4LjA1MDNMNDMuNzU2NyAzMi44NTYyVjM1LjIzOTlINDQuODkwOVYzMi44NTYyTDQ2LjMxMzUgMjguMDUwM0g0NS4yMzdMNDQuMzcxOSAzMS4zMTgzTDQzLjUwNjggMjguMDUwM0g0Mi4zMzQyWk0xNS40NDAzIDIyLjkzNjhMMTQuMTEzOSAzMS42NjQzTDEyLjY5MTMgMjIuOTM2OEgxMFYzNS4yMzk5SDExLjcxMDlWMjYuNTUwOEwxMy4xNTI3IDM1LjIzOTlIMTQuOTc4OUwxNi4zMDU0IDI2LjQxNjNWMzUuMjM5OUgxOC4xMzE2VjIyLjkzNjhIMTUuNDQwM1pNMjguODU4NCAyMi45MzY4SDI1LjgwMThWMzUuMjIwN0gyOC44NTg0QzMwLjggMzUuMjIwNyAzMS43NDIgMzQuMTQ0MiAzMS43NDIgMzIuMTgzNFYyNS45NzQxQzMxLjc0MiAyNC4wMTMzIDMwLjggMjIuOTM2OCAyOC44NTg0IDIyLjkzNjhaTTI3Ljc0MzQgMzMuNDcxNFYyNC42ODYxSDI4LjgzOTJDMjkuNDU0MyAyNC42ODYxIDI5LjgxOTYgMjQuOTkzNyAyOS44MTk2IDI1Ljg3OFYzMi4yNzk1QzI5LjgxOTYgMzMuMTYzOCAyOS40NTQzIDMzLjQ3MTQgMjguODM5MiAzMy40NzE0SDI3Ljc0MzRaTTM2Ljk3MDggMjguMTA4SDM0LjMxNzlWMjQuNjQ3N0gzNy42NjI4VjIyLjg5ODNIMzIuMzk1NlYzNS4yMDE1SDM3LjY2MjhWMzMuNDUyMUgzNC4zMTc5VjI5Ljg1NzNIMzYuOTcwOFYyOC4xMDhaTTIwLjU1MzggMjIuOTM2OEgyMy4zNzk3TDI1LjM0MDUgMzUuMjM5OUgyMy4zOTg5TDIzLjA3MjEgMzIuOTkwOEgyMS4wNTM2TDIxLjI4NDMgMzEuMzM3NUgyMi44MDNMMjEuODYxIDI1LjEwOTFMMjAuOTM4MyAzMS4zMzc1TDIwLjY4ODQgMzIuOTkwOEwyMC4zNjE2IDM1LjIzOTlIMTguNTczOEwyMC41NTM4IDIyLjkzNjhaTTE1LjQ0MDMgMzUuOTEyOEwxNC4xMTM5IDQ0LjY0MDNMMTIuNjkxMyAzNS45MTI4SDEwVjQ4LjIxNTlIMTEuNzEwOVYzOS41MjY4TDEzLjE1MjcgNDguMjE1OUgxNC45Nzg5TDE2LjMwNTQgMzkuMzkyM1Y0OC4yMTU5SDE4LjEzMTZWMzUuOTEyOEgxNS40NDAzWk0yMC43NjUyIDQ1LjM5VjM1LjkxMjhIMTguODIzN1Y0NS4yNzQ3QzE4LjgyMzcgNDcuMjM1NSAxOS44MDQxIDQ4LjM2OTcgMjEuNzA3MiA0OC4zNjk3QzIzLjYxMDQgNDguMzY5NyAyNC41OTA4IDQ3LjIzNTUgMjQuNTkwOCA0NS4yNzQ3VjM1LjkxMjhIMjIuNzY0NVY0NS4zOUMyMi43NjQ1IDQ2LjI3NDMgMjIuMzggNDYuNTgxOSAyMS43NjQ5IDQ2LjU4MTlDMjEuMTQ5NyA0Ni41ODE5IDIwLjc2NTIgNDYuMjc0MyAyMC43NjUyIDQ1LjM5Wk0yNy4wMzIyIDQ4LjE5NjdWMzkuMjk2MUwyOS40NTQzIDQ4LjIxNTlIMzEuNDM0NFYzNS45MTI4SDI5LjcwNDNWNDMuMjU2MkwyNy43MjQyIDM1Ljg5MzVIMjUuMzAyVjQ4LjE5NjdIMjcuMDMyMlpNNDguNjU4OCA0MS4wODM5SDQ2LjAwNTlWMzcuNjIzN0g0OS4zNTA4VjM1Ljg3NDNINDQuMDgzNVY0OC4xNzc1SDQ5LjM1MDhWNDYuNDI4MUg0Ni4wMDU5VjQyLjgzMzNINDguNjU4OFY0MS4wODM5Wk01My45MTIzIDQ4LjE3Mkw1My45MjYxIDQ4LjIxNTlINTUuOTA2MUM1NS43MTM5IDQ3Ljc1NDUgNTUuNjk0NiA0Ny4zMTI0IDU1LjY5NDYgNDYuNzE2NVY0NC44MTMzQzU1LjY5NDYgNDMuNTI1MyA1NS4zNjc4IDQyLjYwMjYgNTQuNDA2NyA0Mi4xOTg5QzU1LjI3MTcgNDEuNzk1MiA1NS42NzU0IDQwLjk2ODYgNTUuNjc1NCAzOS42OTk4VjM4LjczODZDNTUuNjc1NCAzNi44MzU1IDU0LjgxMDQgMzUuOTEyOCA1Mi44MTExIDM1LjkxMjhINDkuODg5MVY0OC4yMTU5SDUxLjgxMTVWNDMuMjE3OEg1Mi40ODQzQzUzLjM2ODYgNDMuMjE3OCA1My43NTMxIDQzLjY0MDcgNTMuNzUzMSA0NC43NzQ5VjQ2LjY5NzJDNTMuNzUzMSA0Ny42NjY5IDUzLjgyMjcgNDcuODg3OCA1My45MTIzIDQ4LjE3MlpNNTEuODExNSA0MS40M1YzNy42NjIxVjM3LjY0MjlINTIuNzM0MkM1My40MDcgMzcuNjQyOSA1My43MTQ2IDM4LjAyNzQgNTMuNzE0NiAzOC45MTE3VjQwLjEyMjdDNTMuNzE0NiA0MS4xMjI0IDUzLjI3MjUgNDEuNDMgNTIuNTYxMiA0MS40M0g1MS44MTE1Wk02MS45ODA4IDM4Ljg3MzJDNjEuOTgwOCAzNi44OTMyIDYxLjAxOTYgMzUuNzc4MiA1OS4xMzU3IDM1Ljc3ODJDNTcuMjUxOCAzNS43NzgyIDU2LjI5MDYgMzYuODkzMiA1Ni4yOTA2IDM4Ljg3MzJDNTYuMjkwNiA0MC43NzU1IDU3LjM5MjMgNDEuNzg0MSA1OC40MDQzIDQyLjcxMDRDNTkuMjYzNyA0My40OTcyIDYwLjA1ODQgNDQuMjI0NyA2MC4wNTg0IDQ1LjM5QzYwLjA1ODQgNDYuMjc0MyA1OS42NzM5IDQ2LjU4MTkgNTkuMDU4OCA0Ni41ODE5QzU4LjQ0MzYgNDYuNTgxOSA1OC4wNTkyIDQ2LjI3NDMgNTguMDU5MiA0NS4zOVY0NC40Mjg5SDU2LjIzMjlWNDUuMjc0N0M1Ni4yMzI5IDQ3LjI1NDcgNTcuMjEzMyA0OC4zNjk3IDU5LjExNjUgNDguMzY5N0M2MS4wMTk2IDQ4LjM2OTcgNjIgNDcuMjM1NSA2MiA0NS4yNzQ3QzYyIDQzLjM3MjQgNjAuODk4MyA0Mi4zNjM4IDU5Ljg4NjMgNDEuNDM3NUM1OS4wMjY5IDQwLjY1MDcgNTguMjMyMiAzOS45MjMyIDU4LjIzMjIgMzguNzU3OUM1OC4yMzIyIDM3Ljg3MzYgNTguNTc4MiAzNy41NDY4IDU5LjE5MzMgMzcuNTQ2OEM1OS44MDg1IDM3LjU0NjggNjAuMTU0NSAzNy44NzM2IDYwLjE1NDUgMzguNzU3OVYzOS4zNTM4SDYxLjk4MDhWMzguODczMlpNMzYuNzU5MyAzNS45NTEyVjM1LjkxMjhINDMuNDY4NFYzNy42NjIxSDQxLjQ0OTlWNDguMjE1OUgzOS41MDgzVjM3LjY4MTNIMzguMDY2NUMzNy45NTEyIDM2Ljg5MzIgMzcuNTY2NyAzNi4yMjAzIDM2Ljc1OTMgMzUuOTUxMlpNMzQuODc1NCAzNS43NzgyQzM2Ljc1OTMgMzUuNzc4MiAzNy43MjA1IDM2Ljg5MzIgMzcuNzIwNSAzOC44NzMyVjM5LjM1MzhIMzUuODk0MlYzOC43NTc5QzM1Ljg5NDIgMzcuODczNiAzNS41NDgyIDM3LjU0NjggMzQuOTMzIDM3LjU0NjhDMzQuMzE3OSAzNy41NDY4IDMzLjk3MTggMzcuODczNiAzMy45NzE4IDM4Ljc1NzlDMzMuOTcxOCAzOS45MjMyIDM0Ljc3MDYgNDAuNjUwNyAzNS42MzQ0IDQxLjQzNzVDMzYuNjUxNiA0Mi4zNjM4IDM3Ljc1ODkgNDMuMzcyNCAzNy43NTg5IDQ1LjI3NDdDMzcuNzU4OSA0Ny4yMzU1IDM2Ljc3ODUgNDguMzY5NyAzNC44NzU0IDQ4LjM2OTdDMzIuOTcyMiA0OC4zNjk3IDMxLjk5MTggNDcuMjU0NyAzMS45OTE4IDQ1LjI3NDdWNDQuNDI4OUgzMy44MTgxVjQ1LjM5QzMzLjgxODEgNDYuMjc0MyAzNC4yMDI1IDQ2LjU4MTkgMzQuODE3NyA0Ni41ODE5QzM1LjQzMjggNDYuNTgxOSAzNS44MTczIDQ2LjI3NDMgMzUuODE3MyA0NS4zOUMzNS44MTczIDQ0LjIyNDcgMzUuMDE4NiA0My40OTcyIDM0LjE1NDcgNDIuNzEwNEMzMy4xMzc2IDQxLjc4NDEgMzIuMDMwMyA0MC43NzU1IDMyLjAzMDMgMzguODczMkMzMi4wMzAzIDM2Ljg5MzIgMzIuOTkxNCAzNS43NzgyIDM0Ljg3NTQgMzUuNzc4MloiIGZpbGw9IndoaXRlIi8+Cjwvc3ZnPgo=',
    '100'
	);
}

/**
 * top level menu:
 * callback functions
 */
function mbm_gutenblocks_options_page_html() {
	// check user capabilities
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	global $settings_slug;

	// add error/update messages

	// check if the user have submitted the settings
	// wordpress will add the "settings-updated" $_GET parameter to the url
	if ( isset( $_GET['settings-updated'] ) ) {
		// add settings saved message with the class of "updated"
		add_settings_error(
			'wporg_messages',
			'wporg_message',
			__( 'Settings Saved', $settings_slug ),
			'updated'
		);
	}

	// show error/update messages
	settings_errors( 'wporg_messages' );
	?>
		<div class="wrap">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
			<form action="options.php" method="post">
			<?php
				// output security fields for the registered setting "wporg"
				settings_fields( $settings_slug );
				// output setting sections and their fields
				// (sections are registered for "wporg", each field is registered to a specific section)
				do_settings_sections( $settings_slug );
				// output save settings button
				submit_button( 'Save Settings' );
			?>
			</form>
		</div>
	<?php
}

/**
 * register our wporg_settings_init to the admin_init action hook
 */
add_action( 'admin_init', 'wporg_settings_init' );

/**
 * register our mbm_gutenblocks_options_page to the admin_menu action hook
 */
add_action( 'admin_menu', 'mbm_gutenblocks_options_page' );
